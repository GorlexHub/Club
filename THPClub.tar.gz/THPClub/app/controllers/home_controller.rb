class HomeController < ApplicationController
  def index
  end

  def private
  end
end
