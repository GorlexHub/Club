class ClubsController < ApplicationController
  before_action :set_user, only: [:show, :edit, :update, :destroy]
  authorize_resource
  # GET /clubs
  # GET /clubs.json
  def index
    @users= User.all
  end

  # GET /clubs/1
  # GET /clubs/1.json
  def show
  end

  # GET /clubs/new
  def new
  end

  # GET /clubs/1/edit
  def edit
  end

  # POST /clubs
  # POST /clubs.json
  # PATCH/PUT /clubs/1
  # PATCH/PUT /clubs/1.json

  def update
  end

  # DELETE /clubs/1
  # DELETE /clubs/1.json
  def destroy
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_club
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def club_params
    end
end
